Welcome to our JupyterNotebook ! 

Notebook are an interactive way for beginner to learn who the code work and the physics behind. This Notebook IS NOT for learn how to use the main script in SolPOC. 
This Notebook is for lear, step by step, how SolPOC work by starting to evaluate the optical respons of your first thin layers stack until your first optimization.

We have split the JupyterNotebook in 7 chapters

- Chap 1 is for learn how to calculate reflectivity, transmissivity and absorptivity of a thin layers stack
- Chap 2 is for learn how to use refractive index of real materias
- Chap 3 is for learn how to use EMA (Effective Medium Approximation) for model materials as cermet or porous mixture
- Chap 4 & 5 is for learn how to easly evaluate our thin layers stack, as calculate the solar performances as example 
- Chap 6 & 7 is for lear how to performe an optimization 
