Dossier nécessaire au fonctionnement du code
Material contient tous les indices de réfraction complexe des materiaux, sous forme de fichier texte
Le nom de chaque fichier texte correspond à un materiaux
Chaque fichier texte contient trois colonne
1. les longueurs d'onde (en nm)
2. La partie réel de l'indice de réfraction complexe 
3. La partie imaginaire de l'indice de réfraction complexe

La majorité des données viennent de : https://refractiveindex.info/